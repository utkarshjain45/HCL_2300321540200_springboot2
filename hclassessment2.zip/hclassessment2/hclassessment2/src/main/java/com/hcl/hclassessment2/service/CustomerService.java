package com.hcl.hclassessment2.service;

import com.hcl.hclassessment2.entity.Customer;
import com.hcl.hclassessment2.repository.CustomerRepository;
import jakarta.transaction.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;

import java.util.List;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public ResponseEntity<?> register(Customer customer){
        if (customerRepository.existsByEmail(customer.getEmail())){
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Cutomer Already Present");
        }
        if (customer != null){
            Customer customer1 = customerRepository.save(customer);
            return ResponseEntity.status(HttpStatus.CREATED).body(customer1);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    public ResponseEntity<?> getCustomerById(Long id){
        if (!customerRepository.existsById(id)){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        return ResponseEntity.ok(customerRepository.findById(id));
    }

    public ResponseEntity<?> getAllCustomer(){
        List<Customer> allCustomer = customerRepository.findAll();
        if (allCustomer.size() == 0){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No Customer Present");
        }

        return ResponseEntity.ok(allCustomer);
    }

    public ResponseEntity<?> updateCustomer(Long id, Customer updatedCustomer){
        if (!customerRepository.existsById(id)){
            ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cutomer Not Found");
        }

        Customer customer = customerRepository.findById(id).get();
        customerRepository.delete(customer);
        return ResponseEntity.ok(customerRepository.save(updatedCustomer));
    }

    public ResponseEntity<?> deleteCustomerById(Long id){
        if (!customerRepository.existsById(id)){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Customer customer = customerRepository.findById(id).get();
        customerRepository.delete(customer);
        return ResponseEntity.ok("Customer Deleted");
    }
}
