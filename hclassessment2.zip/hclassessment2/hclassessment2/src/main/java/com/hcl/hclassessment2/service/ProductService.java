package com.hcl.hclassessment2.service;

import com.hcl.hclassessment2.entity.Product;
import com.hcl.hclassessment2.repository.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public ResponseEntity<?> addProduct(Product product){
        if(productRepository.existsById(product.getProductId())){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Product Already Present");
        }

        return ResponseEntity.ok(productRepository.save(product));
    }

    public ResponseEntity<?> getAllProducts() {
        return ResponseEntity.ok(productRepository.findAll());
    }

    public ResponseEntity<?> getProductById(Long id) {
        if (productRepository.existsById(id)){
            return ResponseEntity.ok(productRepository.findById(id));
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
}
